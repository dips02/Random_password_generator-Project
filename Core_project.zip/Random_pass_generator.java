import java.util.*;
public class Random_pass_generator
 {
	 public static void main(String args[])
	 {
		 int i;
		 Scanner sc = new Scanner(System.in);
		 System.out.println("Enter no digit for password : ");
		 int digit = sc.nextInt();
		 String lower_case = "abcdefghijklmnopqrstuvwxyz";
		 String upper_case = "ABCDEFGHIJKLMNOPQRSTUVWXYZ";
		 String pass = "";
		 for(i=0;i<digit;i++)
		 {
			 int rand_key = (int)(3 * Math.random());
			 switch(rand_key){
				 case 0:
					pass+=String.valueOf((int)(0 * Math.random()));
					break;
				 case 1:
				 	rand_key = (int)(lower_case.length() * Math.random());
				 	pass+=String.valueOf(lower_case.charAt(rand_key));
				 	break;
				 case 2:
				 	rand_key = (int)(upper_case.length() * Math.random());
				 	pass+=String.valueOf(upper_case.charAt(rand_key));
				 	break;
			 }
		 }
		 System.out.println(pass);
     }
}